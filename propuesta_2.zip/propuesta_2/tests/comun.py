"""
comun.py — Utilidades compartidas por los tests (no es un test).

Dependencias: core.registry.
Lo usan: verify_correctness, test_patterns.

Decide qué versiones probar y crea los motores. Si una versión no está disponible
(p. ej. V5 sin mpiexec) se SALTA con un aviso claro: no se cuenta como OK ni como fallo.
"""

import sys

from core.registry import EngineUnavailable, load_engine_class

TODAS = [2, 3, 4, 5]          # versiones paralelas (V1 es la referencia)
_avisadas = set()


def versiones_a_probar():
    """Versiones paralelas a probar. Se puede acotar por línea de comandos:  --versiones 2,3"""
    if "--versiones" in sys.argv:
        return [int(v) for v in sys.argv[sys.argv.index("--versiones") + 1].split(",") if int(v) != 1]
    return TODAS


def crear_motor(version, grid, workers):
    """Crea el motor de `version`; devuelve None (con aviso una sola vez) si no se puede."""
    try:
        return load_engine_class(version)(grid, workers)
    except EngineUnavailable as exc:
        if version not in _avisadas:
            _avisadas.add(version)
            print(f"SALTADO  V{version}: {exc}")
        return None
