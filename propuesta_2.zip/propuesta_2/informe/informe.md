# Juego de la Vida paralelo — Informe

**Curso:** Infraestructuras Paralelas y Distribuidas (750023C) · 2026-2 · Profesor: Manuel Alejandro Pastrana Pardo
**Parcial I:** Paralelismo en Acción — Creación de un Juego Paralelizado
**Integrantes:** _(completar nombres y códigos; máximo 3)_

## 1. Introducción y objetivo
Se implementó el Juego de la Vida de Conway sobre una matriz de celdas vivas/muertas con una versión
secuencial (referencia) y cuatro versiones paralelas, todas en Python:

| Versión | Técnica | Qué demuestra |
|---|---|---|
| V1 | Secuencial, Python puro | Base de comparación |
| V2 | Hilos (`threading`) + `Barrier` | Los *Threads* del enunciado; efecto del GIL |
| V3 | Procesos (`ProcessPoolExecutor`) + filas fantasma | Paralelismo real sin memoria compartida |
| V4 | Hilos + NumPy (SMP + SIMD) | Híbrido visto en el Taller 4 |
| V5 | MPI (`mpi4py`, MS-MPI) | Paso de mensajes: intercambio de filas frontera |

El objetivo es mostrar **cuándo ayuda el paralelismo y cuándo no**. El enunciado permite Threads *o* MPI;
se implementaron ambos y un parámetro (`config.MODO_PARALELO`, `--modo`) decide cuál usar. Se entregan
también una GUI en pygame que simula el juego con cualquiera de las versiones, el benchmark, las gráficas
y las pruebas de correctitud.

## 2. El juego y decisiones de diseño
**Reglas** (enunciado): viva con <2 vecinos muere (soledad); con 2 o 3 sobrevive; con >3 muere
(sobrepoblación); muerta con exactamente 3 vecinos nace.

| Decisión | Elección | Justificación |
|---|---|---|
| Frontera | **Toroidal** (los bordes se envuelven) | El glider no muere en el borde; las filas fantasma entre bandas y la envoltura son el mismo mecanismo. Misma frontera en todas las versiones. |
| Lenguaje | Python | Es el de los talleres del curso; la GUI y las gráficas quedan en un solo lenguaje. |
| Threads **y** MPI | Ambos, seleccionables | Permite comparar memoria compartida vs. paso de mensajes con el mismo kernel. |
| División | **Bandas de filas** | Una fila es memoria contigua (localidad de caché); la frontera de cada banda son solo 2 filas; reparto simple. Bloques 2D reducirían el perímetro solo con muchos trabajadores y obligan a manejar 8 vecinos y esquinas entre bloques. |
| Matriz | Lista de `bytearray` (0/1) | Mutable (la GUI pinta celdas), compacta, y una fila se envía barata a otro proceso. V4 y la GUI la convierten a NumPy en los bordes. |
| Regla | Escrita **una sola vez** (`core/rules.py`) | Si cada versión copiara la regla, la comparación de rendimiento dejaría de ser justa: solo cambia *quién* recorre *qué* filas. |

## 3. Implementación secuencial (V1)
- **Doble búfer:** `compute_rows` lee de `actual` y escribe en `siguiente`; al terminar la generación se
  intercambian las *referencias* (no se copian celdas). Con una sola matriz, una celda ya actualizada
  contaminaría a su vecina y el resultado dependería del orden de recorrido.
- **Kernel por filas** (`compute_rows`): suma, columna a columna, las tres filas vecinas y luego tres
  columnas contiguas; el bucle interno no usa módulos ni índices. Una celda vive en la siguiente
  generación si la suma de su ventana 3×3 vale 3, o vale 4 y la celda estaba viva.
- **Referencia lenta:** `count_neighbors` + `next_cell_state` aplican la regla celda a celda tal como la
  escribe el enunciado; los tests comprueban que el kernel rápido da lo mismo.
- **Trampa serial:** el bucle de generaciones no se puede paralelizar (la generación *t+1* depende de la
  *t*); lo paralelizable es el trabajo *dentro* de cada generación (las celdas son independientes).
- **Semilla fija** (`config.SEMILLA`, generador `random.Random(seed)` propio): todas las versiones y todas
  las pruebas parten del mismo estado inicial.

## 4. Estrategia de paralelización
**Descomposición por dominio** (Sesión de descomposición, Taller 2): la matriz se divide en bandas
contiguas de filas, una por trabajador. El reparto balancea la carga: con `h` filas y `p` trabajadores,
las primeras `h mod p` bandas reciben una fila más (1000 filas / 7 = seis bandas de 143 y una de 142).
Si `p > h`, `p` se limita a `h`.

**Ciclo de una generación (común a todas las versiones):**
```
  [ cada trabajador: calcula SU banda de la generación t+1 leyendo la generación t ]
                              │
              ── sincronización (barrera / espera de resultados / mensajes) ──
                              │
                    la generación t+1 pasa a ser la actual
```

- **V2 – hilos + Barrier.** `p` hilos *persistentes* (se crean una vez). Cada hilo calcula su banda de
  `siguiente` y espera en una `Barrier` por generación cuya *acción* (la ejecuta un solo hilo) intercambia
  `actual` y `siguiente`. Dos barreras más (inicio y fin de `run`, con `p+1` partes para incluir al hilo
  que llama) permiten reutilizar los mismos hilos. Los hilos leen `actual` (compartida, solo lectura) y
  escriben filas disjuntas de `siguiente`: **no hay ningún Lock en el cómputo**.
- **V3 – procesos + filas fantasma.** Un `ProcessPoolExecutor` persistente. Cada generación se envía a
  cada proceso su banda más una fila vecina arriba y otra abajo (*filas fantasma*, que en toroidal
  envuelven en los extremos); el worker devuelve su banda nueva. Los resultados se recogen con
  `as_completed` guardando a qué banda corresponde cada `future` y se ensamblan en orden. La espera de
  todos los resultados es la sincronización. Se paga la **copia** de datos (pickle) en cada generación.
- **V4 – híbrida SMP + SIMD.** Hereda de V2 (mismos hilos, bandas y barrera) y solo cambia el kernel:
  cada hilo cuenta vecinos sumando 8 vistas desplazadas de un arreglo NumPy y aplica las reglas con
  operaciones vectorizadas. NumPy libera el GIL en operaciones grandes, de modo que los hilos sí
  aportan algo.
- **V5 – MPI.** El proceso principal lanza `p` workers (`MPI.COMM_SELF.Spawn`). Cada worker **conserva
  su banda** entre generaciones y en cada una intercambia con sus vecinos **solo las filas de borde**
  mediante `Sendrecv` en un anillo (la frontera toroidal es el cierre del anillo); luego calcula con el
  mismo kernel. El padre solo coordina (`run`) y reúne las bandas cuando hace falta (`snapshot`).

Todas las versiones comparten el contrato `Engine` (`run`, `step`, `snapshot`, `close`); la GUI, el
benchmark y los tests dependen solo de él, así que cambiar de versión no toca nada más.

## 5. Desafíos encontrados y cómo se resolvieron
1. **Condiciones de carrera.** Con doble búfer y filas disjuntas no hay dos escritores sobre la misma
   celda, por lo que no se necesita Lock; “la mejor sincronización es la que no necesitas”. Un Lock
   solo sería necesario para un contador compartido (p. ej. celdas vivas); se evita calculando parciales
   por trabajador y sumándolos al final.
2. **Sincronización entre generaciones.** Ningún hilo puede empezar la generación *t+1* hasta que todos
   terminaron de escribirla: la `Barrier` con acción de intercambio garantiza además que todos ven el
   *swap* antes de continuar.
3. **Deadlock con `Barrier`.** Un número de partes incorrecto cuelga el programa, y un hilo que falla
   con excepción deja a los demás esperando para siempre. Se usa `timeout`, se captura
   `BrokenBarrierError`, el primer error se guarda y se re-lanza en `run()`, y la barrera se aborta para
   liberar a los demás. Se comprobó inyectando un fallo en un hilo: `run()` propaga el error y `close()`
   termina sin colgarse.
4. **El GIL.** Con kernel en Python puro, los hilos no aceleran (ver §8). Es el hallazgo central de V2.
5. **Costo de arranque en Windows (*spawn*).** V3 y V5 tardan segundos en crear `p` procesos. Se crean una
   sola vez en `__init__`, el tiempo se mide **aparte** (`tiempo_setup_s`) y se hace un calentamiento
   antes de cronometrar. Con un solo ciclo de calentamiento algunos procesos seguían arrancando durante
   las primeras generaciones (se vio al perfilar: 400 ms/gen al principio, 34 ms después); se corrigió
   repitiendo el calentamiento hasta que respondan los `p` procesos.
6. **Esquinas toroidales.** Dependen de filas *y* columnas envueltas. Se resuelve rellenando cada fila con
   su última/primera celda y usando filas fantasma para el eje vertical; se prueba con un glider que
   cruza la esquina de la matriz.
7. **`as_completed` no respeta el orden de las bandas.** Se guarda el índice de cada `future` antes de
   ensamblar.
8. **MPI en Windows.** MS-MPI solo permite `Spawn` si el proceso padre arranca bajo `mpiexec`
   (`mpiexec -n 1 python -m ...`); sin él, V5 se declara “no disponible” con un mensaje claro (la GUI no
   se cae) y el resto de las versiones sigue funcionando.
9. **Comparación justa de V4.** V4 es ~15× más rápida que V1 *solo por vectorizar*. Compararla con V1 y
   llamarlo “speedup de paralelismo” sería engañoso; su speedup se calcula contra **V4 con 1 hilo**.

## 6. Metodología de pruebas
**Hardware** (`results/hardware.txt`): AMD Ryzen 7 8845HS, **8 núcleos físicos / 16 lógicos**, 15,3 GB de
RAM, Windows 11, Python 3.14.5 **con GIL**, NumPy 2.5.3, mpi4py 4.1.2 (MS-MPI 10.1), plan de energía
“Equilibrado”.

**Verificación de correctitud previa a medir** (`python -m tests.verify_correctness`, `test_patterns`,
`test_partition`):
- Kernel rápido = regla celda a celda del enunciado.
- V2, V3, V4 y V5 = V1 (comparación celda a celda y por hash) en 4 tamaños (30×40, 1000×16, 5×9, 3×3),
  `p ∈ {1, 2, 3, 4, 7, 8}` (incluye filas no divisibles y `p > h`) y 1, 2, 10 y 50 generaciones:
  **24/24 configuraciones por versión, todas iguales a V1.**
- Blinker (periodo 2), glider (+1,+1 cada 4 generaciones, también cruzando la esquina) y bloque
  (estable), colocados sobre la frontera entre bandas, con `p ∈ {1, 2, 4, 8}`: todo OK.
- Se comprobó que los tests *detectan* errores: al romper a propósito la fila fantasma de V3, los tres
  tests de patrones fallan.

**Benchmark** (`python -m benchmark.run_benchmark`, sin GUI): tamaños 100, 500 y 1000 (matriz cuadrada);
`p ∈ {1, 2, 4, 8, 16}`; **50 generaciones**; **7 repeticiones**; se reporta la **mediana**. Se cronometra
solo `run(50)` con `time.perf_counter` tras un calentamiento de 1 generación; el arranque de hilos/procesos
se mide aparte. Misma semilla (12345, densidad 0,30) en todas las pruebas. El speedup es
`S(p) = T(V1) / T(p)`, siempre contra V1 (nunca contra V2/V3 con 1 trabajador); para V4 la base es V4 con
1 hilo. La eficiencia es `E = S/p` y la fracción serial se estima con Amdahl:
`f ≈ (1/S − 1/p) / (1 − 1/p)`. V5 se midió en una corrida aparte bajo `mpiexec` (se agrega al mismo CSV).

## 7. Resultados y gráficas
Datos completos: `results/tiempos.csv` (441 mediciones) y `results/resumen.md`.

![Tiempo vs tamaño](../results/figures/tiempo_vs_tamano.png)
![Tiempo vs trabajadores](../results/figures/tiempo_vs_trabajadores.png)
![Speedup vs trabajadores](../results/figures/speedup_vs_trabajadores.png)
![Speedup de V4 contra su base](../results/figures/speedup_v4_vs_v4_1hilo.png)
![Eficiencia](../results/figures/eficiencia_vs_trabajadores.png)

**Speedup contra V1 (mediana de 7 repeticiones, 50 generaciones)**

| Matriz | V1 (s) | Versión | p=1 | p=2 | p=4 | p=8 | p=16 |
|---|---|---|---|---|---|---|---|
| 100×100 | 0,115 | V2 hilos | 0,99 | 0,89 | 0,87 | 0,82 | 0,74 |
| | | V3 procesos | 0,72 | 1,21 | 1,42 | 1,16 | 0,65 |
| | | V5 MPI | 1,03 | 1,81 | 3,22 | 3,11 | 0,75 |
| 500×500 | 2,629 | V2 hilos | 0,99 | 1,01 | 0,99 | 0,98 | 0,90 |
| | | V3 procesos | 1,05 | 1,89 | 3,35 | 5,04 | 5,31 |
| | | V5 MPI | 1,07 | 1,95 | 3,67 | 6,40 | 6,62 |
| 1000×1000 | 10,091 | V2 hilos | 1,00 | 1,03 | 1,05 | 0,99 | 1,00 |
| | | V3 procesos | 0,99 | 1,81 | 3,44 | 5,93 | 7,59 |
| | | V5 MPI | 1,06 | 2,01 | 3,75 | 6,90 | 9,19 |

**V4 (hilos + NumPy), speedup contra V4 con 1 hilo** (tiempo de V4 con 1 hilo entre paréntesis):

| Matriz | p=2 | p=4 | p=8 | p=16 | Factor de V4(1 hilo) sobre V1 |
|---|---|---|---|---|---|
| 100×100 (0,008 s) | 0,86 | 0,34 | 0,16 | 0,09 | 13,9× |
| 500×500 (0,147 s) | 1,54 | 2,40 | 2,07 | 1,34 | 17,8× |
| 1000×1000 (0,646 s) | 1,89 | 3,27 | 3,98 | 3,35 | 15,6× |

**Costo de arranque (`tiempo_setup_s`, mediana, 1000×1000):** V2 ≈ 0,002–0,005 s; V3 ≈ 0,6 s (p=1), 6,3 s
(p=8), 13,8 s (p=16); V5 ≈ 0,5 s (p=1), 6,2 s (p=8), 19,4 s (p=16). Es un costo fijo que se amortiza solo
si la simulación es larga.

**Fracción serial estimada (Amdahl), 1000×1000:** V3 ≈ 0,05 (p=4 y 8); V5 ≈ 0,02 (p=4 y 8); V4 ≈ 0,06–0,14
(p=2 a 8).

## 8. Análisis y conclusiones
1. **V2 (hilos, Python puro) no acelera: speedup ≈ 1 en todos los tamaños** (0,99–1,05 con hasta 16
   hilos; incluso baja a 0,74 en 100×100). Es el efecto del **GIL**: solo un hilo ejecuta bytecode de Python
   a la vez, así que los hilos se turnan y solo añaden barreras. La fracción serial estimada ≈ 1 lo
   confirma: para este kernel, el código se comporta como 100 % serial. Es un resultado válido y esperado,
   no un error: lo verificamos con 24/24 comparaciones correctas contra V1.
2. **Los procesos sí escalan (V3 y V5), porque cada proceso tiene su propio intérprete y su GIL.** En
   1000×1000 con 8 procesos: V3 = 5,9× y V5 = 6,9× (eficiencias 0,74 y 0,86). Con 16 procesos:
   7,6× y 9,2×.
3. **El tamaño importa.** En 100×100 el trabajo por generación (≈ 2 ms) es comparable al costo de
   sincronizar/comunicar: V3 apenas llega a 1,4× (y empeora con 8 y 16 procesos) y V5 a 3,2×, que baja a
   0,75× con 16. A mayor matriz, la razón cómputo/comunicación sube (el cómputo crece con *h·w* y la
   frontera solo con *w*) y el speedup crece: con 1000×1000 las eficiencias con 4 procesos son 0,86 (V3) y
   0,94 (V5). Es la conclusión principal: **el paralelismo ayuda cuando hay trabajo suficiente para
   amortizar su costo, y perjudica cuando no.**
4. **V5 (MPI) supera a V3 en todos los tamaños grandes** (6,9× vs 5,9× con 8 procesos en 1000×1000). Nuestra
   interpretación, consistente con las fracciones seriales medidas (≈ 0,02 vs ≈ 0,05): V3 reconstruye y
   reenvía las bandas desde el proceso principal en cada generación y ensambla el resultado (parte serial
   que se repite 50 veces), mientras que en V5 cada worker conserva su banda y solo intercambia 2 filas
   por generación. No se aisló esta causa con una medición dedicada, por lo que se presenta como
   explicación más probable y no como hecho comprobado.
5. **El speedup se estanca al pasar los núcleos físicos.** La máquina tiene 8 núcleos físicos y 16 lógicos
   (SMT): de 8 a 16 procesos el speedup de V5 pasa de 6,9× a 9,2× (en 500×500 solo de 6,4× a 6,6×) y la
   eficiencia cae de 0,86 a 0,57. Un núcleo lógico extra no equivale a un núcleo físico, y además crecen
   los costos de comunicación y de arranque (hasta ~19 s con 16 procesos).
6. **V4 aísla el efecto de SIMD vs SMP.** Solo vectorizar con NumPy (V4 con 1 hilo) ya es ≈ 14–18× más
   rápido que V1: **esa es la mayor ganancia de todo el proyecto**, y no es paralelismo de hilos. Sobre esa
   base, los hilos aportan hasta 3,98× con 8 hilos en 1000×1000 (NumPy libera el GIL en operaciones
   grandes, por lo que a diferencia de V2 aquí los hilos sí ayudan). Con bandas pequeñas el efecto se
   invierte: en 100×100, más hilos *empeoran* (0,34× con 4) porque el trabajo de cada banda es menor que el
   costo de la barrera y de las operaciones NumPy; y en 1000×1000 el speedup se estanca en 8 hilos y baja
   con 16. Combinado: V4 con 8 hilos es ≈ 62× más rápida que V1 en 1000×1000, pero ese factor mezcla
   vectorización y paralelismo y por eso no se usa como “speedup”.
7. **Ley de Amdahl.** Con f ≈ 0,02–0,05, el máximo teórico con 8 procesos sería ≈ 1/(f + (1−f)/8) ≈ 6,0–7,0×,
   cercano a lo medido; la parte serial (empaquetado, ensamblado, intercambio, coordinación del padre) y
   los costos por generación explican por qué no se alcanza S = p.
8. **Limitaciones.** (a) Medidas en una sola máquina y sistema operativo, con el plan de energía
   “Equilibrado” y aplicaciones en segundo plano no controladas del todo; hay variación entre corridas
   (se usó la mediana de 7). (b) Se probó solo matriz cuadrada y una densidad (0,30). (c) La GUI usa una matriz
   de 100×100 y no sirve para medir rendimiento (en esa escala V1 puede ir más rápida que las paralelas).
   (d) El arranque de procesos en Windows (*spawn*) es lento y no se optimizó (p. ej. memoria compartida).

**Conclusión general.** Para este problema (*stencil* de memoria compartida, con dependencia entre
generaciones y fronteras pequeñas) el paralelismo es efectivo cuando se evita el GIL (procesos o MPI) y la
matriz es suficientemente grande (≥ 500×500); con hilos y Python puro no hay ganancia, y la vectorización
supera por mucho a añadir hilos o procesos. MPI, al conservar los datos en cada proceso, escala mejor que
reenviar las bandas a un pool.

## 9. Referencias
- Enunciado del Parcial I (`Parcial I.pdf`), Infraestructuras Paralelas y Distribuidas 2026-2.
- Arpaci-Dusseau, *Operating Systems: Three Easy Pieces* (OSTEP), caps. 28–30 (locks, variables de
  condición, semáforos).
- Documentación de Python: `threading` (`Barrier`), `multiprocessing`, `concurrent.futures`.
- Documentación de `mpi4py` y de Microsoft MPI.
- Material de las sesiones y talleres 1–4 del curso (descomposición por dominio, concurrencia, SMP/SIMD,
  Ley de Amdahl).
